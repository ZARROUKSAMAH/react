import React, { useState, useEffect } from "react";
let slideInterval;

const User = () => {
  const [activeSlide, setActiveSlide] = useState(0);


  useEffect(() => {
    startSlider();
    return () => {
      pauseSlider();
    };
  })

  const pauseSlider = () => {
    clearInterval(slideInterval);
  };

  const startSlider = () => {
    slideInterval = setInterval(() => {
      handleNextSlide();
    }, 9500);
  }
  const handlePrevSlide = () => {
    setActiveSlide((prevSlide) => (prevSlide === 0 ? 2 : prevSlide - 1));
  };

  const handleNextSlide = () => {
    setActiveSlide((prevSlide) => (prevSlide === 2 ? 0 : prevSlide + 1));
  };


  const slideData = [
    {
      imageUrl: 'https://tecdn.b-cdn.net/img/Photos/Slides/img%20(15).jpg',
      label: 'First slide label',
      content: 'Some representative placeholder content for the first slide..',
    },
    {
      imageUrl: 'https://tecdn.b-cdn.net/img/Photos/Slides/img%20(22).jpg',
      label: 'Second slide label',
      content: 'Some representative placeholder content for the Second slide..',
    },
    {
      imageUrl: 'https://tecdn.b-cdn.net/img/Photos/Slides/img%20(23).jpg',
      label: 'Third slide label',
      content: 'Some representative placeholder content for the third slide..',
    },
  ];
  return (
    <div
      id="carouselExampleCaptions"
      className="relative"
      data-te-carousel-init
      data-te-ride="carousel">
      <div className="absolute bottom-0 left-0 right-0 z-[2] mx-[15%] mb-4 flex list-none justify-center p-0" data-te-carousel-indicators>
        {slideData.map((_, index) => (
          <button
            key={index}
            type="button"
            data-te-target="#carouselExampleCaptions"
            data-te-slide-to={index}
            className={`mx-[3px] box-content h-[3px] w-[30px] flex-initial cursor-pointer border-0 border-y-[10px] border-solid border-transparent bg-white bg-clip-padding p-0 -indent-[999px] ${activeSlide === index ? 'opacity-100' : 'opacity-50'
              } transition-opacity duration-[600ms] ease-[cubic-bezier(0.25,0.1,0.25,1.0)] motion-reduce:transition-none`}
            onClick={() => setActiveSlide(index)}
            aria-current={activeSlide === index}
            aria-label={`Slide ${index + 1}`}
          ></button>
        ))}
      </div>
      {slideData.map((slide, index) => (
        <div
          key={index}
          className={`relative w-full h-screen transition-transform duration-[600ms] ease-in-out motion-reduce:transition-none ${activeSlide === index ? 'block' : 'hidden'
            }`}
        >
          <img src={slide.imageUrl} className="block w-full h-full object-cover" alt={`Slide ${index + 1}`} />
          <div className="absolute inset-0 flex items-center justify-center text-center text-white">
            <div
              className="absolute inset-x-[15%] top-70 hidden py-5 text-center text-white md:block">
              <h5 class="text-6xl font-semibold m-5">{slide.label}</h5>
              <p>
                {slide.content}
              </p>
            </div>
          </div>
        </div>
      ))}
      {/* Carousel controls - prev item */}
      <button
        className="absolute bottom-0 left-0 top-0 z-[1] flex w-[15%] items-center justify-center border-0 bg-none p-0 text-center text-white opacity-50 transition-opacity duration-150 ease-[cubic-bezier(0.25,0.1,0.25,1.0)] hover:text-white hover:no-underline hover:opacity-90 hover:outline-none focus:text-white focus:no-underline focus:opacity-90 focus:outline-none motion-reduce:transition-none"
        type="button"
        onClick={handlePrevSlide}
      >
        <span className="inline-block h-8 w-8">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth="1.5"
            stroke="currentColor"
            className="h-6 w-6"
          >
            <path d="M15.75 19.5L8.25 12l7.5-7.5" />
          </svg>
        </span>
        <span className="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">Previous</span>
      </button>

      {/* Carousel controls - next item */}
      <button
        className="absolute bottom-0 right-0 top-0 z-[1] flex w-[15%] items-center justify-center border-0 bg-none p-0 text-center text-white opacity-50 transition-opacity duration-150 ease-[cubic-bezier(0.25,0.1,0.25,1.0)] hover:text-white hover:no-underline hover:opacity-90 hover:outline-none focus:text-white focus:no-underline focus:opacity-90 focus:outline-none motion-reduce:transition-none"
        type="button"
        onClick={handleNextSlide}
      >
        <span className="inline-block h-8 w-8">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth="1.5"
            stroke="currentColor"
            className="h-6 w-6"
          >
            <path d="M8.25 4.5l7.5 7.5-7.5 7.5" />
          </svg>
        </span>
        <span className="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">Next</span>
      </button>
    </div>
  );
}

export default User