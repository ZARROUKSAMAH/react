/* eslint-disable jsx-a11y/img-redundant-alt */
import React from "react";
import { Link } from 'react-router-dom';
export default function Slider() {

    return (
      <>
         <h4 className="text-2xl font-bold text-center m-10 flex items-center justify-center  dark:text-black pb-2 md:hover:text-blue-700">News</h4>
          <div className="grid grid-cols-1 sm:grid-cols-1 m-20 p-10 hover:shadow-xl md:grid-cols-2 h-auto lg:grid-cols-3 xl:grid-cols-2 gap-2">
             <Link to="/user">
                 <div className="rounded overflow-hidden hover:shadow-xl">
                    <img
                      className="w-full"
                      src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTa0xAVZpG4yf99sNRSecwaMHzBKKIe--6UTLgxGylz92DlrHjepxEwf-NgtD5V1yyVh5U&usqp=CAU"
                      alt="image"
                      
              />
                  <div className="px-6 py-4">
                      <div className="font-bold text-xl mb-2"></div>
                        <p className="text-gray-700 text-base">
                          react tailwind css card with image It is a long established fact that a reader will be distracted by the readable content"
                      </p>
                  </div>
                <div className="px-6 pt-4 pb-2">
                  <span className="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">#photography</span>
                  <span className="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">#travel</span>
                  <span className="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">#winter</span>
                </div>      
                </div>       
            </Link>
            <Link to="/admin">
                <div className="rounded overflow-hidden hover:shadow-xl">
                        <img
                        className="w-full"
                        src="https://bloximages.chicago2.vip.townnews.com/thetimestribune.com/content/tncms/assets/v3/editorial/2/ed/2edbebde-ec11-11ea-9a29-17cf173ad57d/5f4dd76e4af8c.image.jpg?resize=400%2C266"
                        alt="image"
                        
                />
                    <div className="px-6 py-4">
                        <div className="font-bold text-xl mb-2"></div>
                            <p className="text-gray-700 text-base">
                            BACK TO SCHOOL 2023-2024 - DATES TO REMEMBER 
                        </p>
                    </div>
                    <div className="px-6 pt-4 pb-2">
                    <span className="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">#photography</span>
                    <span className="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">#travel</span>
                    <span className="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">#winter</span>
                    </div>      
                </div>
            </Link> 
          </div>
        </>
    );
}