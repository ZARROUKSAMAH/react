import React, { useState } from "react";
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { Link } from 'react-router-dom';
import EditableComponent from './Edit';


const Admin = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4, 
    slidesToScroll: 1,
  };

  const [editingSlider, setEditingSlider] = useState(null);

  // Function to start editing a slider
  const startEditing = (sliderId) => {
    setEditingSlider(sliderId);
  };

  // Function to stop editing
  const stopEditing = () => {
    setEditingSlider(null);
  };

  const sliders = [
    {
      id: 1,
      title: "Slider 1",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTa0xAVZpG4yf99sNRSecwaMHzBKKIe--6UTLgxGylz92DlrHjepxEwf-NgtD5V1yyVh5U&usqp=CAU",
      content: "Content for Slider 1",
    },
    {
      id: 2,
      title: "Slider 2",
      image: "https://bloximages.chicago2.vip.townnews.com/thetimestribune.com/content/tncms/assets/v3/editorial/2/ed/2edbebde-ec11-11ea-9a29-17cf173ad57d/5f4dd76e4af8c.image.jpg?resize=400%2C266",
      content: "Content for Slider 2",
    },
    {
      id: 1,
      title: "Slider 3",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTa0xAVZpG4yf99sNRSecwaMHzBKKIe--6UTLgxGylz92DlrHjepxEwf-NgtD5V1yyVh5U&usqp=CAU",
      content: "Content for Slider 1",
    },
    {
      id: 2,
      title: "Slider 4",
      image: "https://bloximages.chicago2.vip.townnews.com/thetimestribune.com/content/tncms/assets/v3/editorial/2/ed/2edbebde-ec11-11ea-9a29-17cf173ad57d/5f4dd76e4af8c.image.jpg?resize=400%2C266",
      content: "Content for Slider 2",
    },
    {
      id: 1,
      title: "Slider 5",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTa0xAVZpG4yf99sNRSecwaMHzBKKIe--6UTLgxGylz92DlrHjepxEwf-NgtD5V1yyVh5U&usqp=CAU",
      content: "Content for Slider 1",
    },
    {
      id: 2,
      title: "Slider 6",
      image: "https://bloximages.chicago2.vip.townnews.com/thetimestribune.com/content/tncms/assets/v3/editorial/2/ed/2edbebde-ec11-11ea-9a29-17cf173ad57d/5f4dd76e4af8c.image.jpg?resize=400%2C266",
      content: "Content for Slider 2",
    },
    {
      id: 1,
      title: "Slider 7",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTa0xAVZpG4yf99sNRSecwaMHzBKKIe--6UTLgxGylz92DlrHjepxEwf-NgtD5V1yyVh5U&usqp=CAU",
      content: "Content for Slider 1",
    },
    {
      id: 2,
      title: "Slider 8",
      image: "https://bloximages.chicago2.vip.townnews.com/thetimestribune.com/content/tncms/assets/v3/editorial/2/ed/2edbebde-ec11-11ea-9a29-17cf173ad57d/5f4dd76e4af8c.image.jpg?resize=400%2C266",
      content: "Content for Slider 2",
    },
  ];

  return (
    <>
      <h4 className="text-2xl font-bold text-center m-10 flex items-center justify-center dark:text-black pb-2 md:hover:text-blue-700">News</h4>
      <Slider {...settings}>
        {sliders.map((slider) => (
          <div key={slider.id} className="rounded m-2 p-2 overflow-hidden hover:shadow-xl">
            <img
              className="w-full"
              src={slider.image}
              alt={`Slider ${slider.id}`}
            />
            <div className="px-6 py-4">
              <div className="font-bold text-xl mb-2">{slider.title}</div>
              <p className="text-gray-700 text-base">{slider.content}</p>
            </div>
            <button
              type="button"
              class="inline-block rounded bg-primary px-6 pb-2 pt-2.5 text-xs font-medium uppercase leading-normal m-2 text-white shadow-[0_4px_9px_-4px_#3b71ca] bg-blue-600 transition duration-150 ease-in-out hover:bg-primary-600 hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:bg-primary-600 focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:outline-none focus:ring-0 active:bg-primary-700 active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] dark:shadow-[0_4px_9px_-4px_rgba(59,113,202,0.5)] dark:hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)]"
              data-te-ripple-init
              data-te-ripple-color="light">
              Add
            </button>
            {editingSlider === slider.id ? (
              <EditableComponent
                initialTitle={slider.title}
                initialContent={slider.content}
                initialImage={slider.image}
              />
            ) : (
              <Link to="/edit">
                <button
                  type="button"
                  onClick={() => startEditing(slider.id)}
                  className="inline-block rounded bg-primary px-6 pb-2 pt-2.5 text-xs font-medium uppercase leading-normal m-2 text-white shadow-[0_4px_9px_-4px_#3b71ca] bg-green-600 transition duration-150 ease-in-out hover:bg-primary-600 hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:bg-primary-600 focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:outline-none focus:ring-0 active:bg-primary-700 active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] dark:shadow-[0_4px_9px_-4px_rgba(59,113,202,0.5)] dark:hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)]"
                  data-te-ripple-init
                  data-te-ripple-color="light"
                >
                  Edit
                </button>
              </Link>
            )}
            <button
              type="button"
              class="inline-block rounded bg-primary px-6 pb-2 pt-2.5 text-xs font-medium uppercase leading-normal m-2 text-white shadow-[0_4px_9px_-4px_#3b71ca] bg-red-800 transition duration-150 ease-in-out hover:bg-primary-600 hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:bg-primary-600 focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:outline-none focus:ring-0 active:bg-primary-700 active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] dark:shadow-[0_4px_9px_-4px_rgba(59,113,202,0.5)] dark:hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)]"
              data-te-ripple-init
              data-te-ripple-color="light">
              Delete
            </button>
          </div>
        ))}
      </Slider>
    </>
  );
}

export default Admin