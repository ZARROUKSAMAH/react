import React, { useState } from 'react';

const EditableComponent = ({ title, initialTitle, initialContent, initialImage }) => {
    const [editedTitle, setEditedTitle] = useState(initialTitle);
    const [content, setContent] = useState(initialContent);
    const [image, setImage] = useState(initialImage);

    const handleTitleChange = (e) => {
        setEditedTitle(e.target.value);
    };

    const handleContentChange = (e) => {
        setContent(e.target.value);
    };

    const handleImageChange = (e) => {
        const selectedImage = e.target.files[0];
        if (selectedImage) {
            const reader = new FileReader();
            reader.onload = (event) => {
                setImage(event.target.result);
            };
            reader.readAsDataURL(selectedImage);
        }
    };

    const handleSave = () => {
     
    };

    return (
        <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-5xl m-10 font-semibold mb-4">Edit</h2>
            <div className="mb-4 m-10">
                <img
                    src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTa0xAVZpG4yf99sNRSecwaMHzBKKIe--6UTLgxGylz92DlrHjepxEwf-NgtD5V1yyVh5U&usqp=CAU"
                    alt="Uploaded Image"
                    className="max-w-full m-5 max-h-64 mb-2 rounded-lg"
                />
                <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="w-80 m-7 p-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                />
            </div>
            <div>
                <input
                    type="text"
                    value={editedTitle}
                    placeholder='Title'
                    onChange={handleTitleChange}
                    className="w-96 m-14 p-2 border-b-2 border-gray-300 focus:border-blue-500"
                />
            </div>
            <div className="mt-4">
                <textarea
                    value={content}
                    onChange={handleContentChange}
                    className="w-96  h-40 p-14 ml-14 border-2 border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                />
            </div>
            <button
                onClick={handleSave}
                className="mt-6 ml-14 w-96 bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-full"
            >
                Save
            </button>
        </div>
    );
};

export default EditableComponent;
